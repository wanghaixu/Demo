//
//  DetailViewController.h
//  CalendarEventSdk
//
//  Created by Clement on 15/1/14.
//  Copyright (c) 2015年 Clement. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (strong,nonatomic) NSArray *eventArray;

@end
